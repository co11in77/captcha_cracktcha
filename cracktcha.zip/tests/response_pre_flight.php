<html>
<body bgcolor="#ccffcc">
<br></br>
<br></br>
<h2>Congrats! You successfully entered:  <?php echo $_POST["value1"]; ?><br></h2>
		  <br>
	     <button onclick="window.location.href = '/';">Go Home!</button><button onclick="window.location.href = '/tests/pre_flight.php';">Go Back!</button>


</body>
</html>