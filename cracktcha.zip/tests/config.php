<?php
 $public_recaptcha_key = "6LeAV5AUAAAAANiKSeybHaqm1Z2n1vdKObuhFsss";
 $secret_recaptcha_key = "6LeAV5AUAAAAAJI_WQ3jOA1g4Aax7OZu5ClikG87";
 $domain = "http://localhost";
?>