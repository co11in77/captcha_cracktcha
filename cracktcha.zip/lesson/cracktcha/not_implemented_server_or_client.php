<html>
<video controls autoplay>
  <source src="not_implemented_server_or_client.mp4" type="video/mp4">
</video>
		  <br>
		  <br>
	     <button onclick="window.location.href = '/';">Go Home!</button>
</html>