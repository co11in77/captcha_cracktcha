<html>
<video controls autoplay>
  <source src="works_deleted.mp4" type="video/mp4">
</video>
		  <br>
		  <br>
	     <button onclick="window.location.href = '/';">Go Home!</button>
</html>