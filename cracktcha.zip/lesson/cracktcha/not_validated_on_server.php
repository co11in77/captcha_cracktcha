<html>
<video controls autoplay>
  <source src="not_validated_on_server.mp4" type="video/mp4">
</video>
		  <br>
		  <br>
	     <button onclick="window.location.href = '/';">Go Home!</button>
</html>